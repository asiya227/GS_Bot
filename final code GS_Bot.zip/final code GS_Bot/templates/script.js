const inputBtn = document.getElementById('submit_btn');
const inputEl = document.getElementById('input_field');

function getInputVal() {
  console.log('err');
  console.log(inputEl.value);
}

inputBtn.addEventListener('click', getInputVal);
