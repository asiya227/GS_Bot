import json
from flask import Flask, render_template, request, redirect, url_for, session, jsonify
from MySQLdb import connect
import pymysql,re
import final_

app = Flask(__name__)

app.secret_key = 'rahima'

@app.route('/')
def home():
    if 'username' in session:
        return render_template('home.html', username=session['username'])
    else:
        return render_template('home.html')

#register page
@app.route('/register', methods=['GET', 'POST'])
def register():
    message = ''
    if request.method == 'POST' and 'username' in request.form and 'email' in request.form and 'password' in request.form:
        userName = request.form['username']
        email = request.form['email']
        password = request.form['password']
        connection = pymysql.connect(host='localhost', user='root', password='', database='chat')

        # Create cursor
        cursor = connection.cursor()
        cursor.execute('SELECT * FROM flask_users WHERE email = %s', (email,))
        account = cursor.fetchone()
        if account:
            message = 'Account already exists!'
        elif not re.match(r'[^@]+@[^@]+\.[^@]+', email):
            message = 'Invalid email address!'
        elif not userName or not password or not email:
            message = 'Please fill out the form!'
        else:
            cursor.execute('INSERT INTO flask_users VALUES (NULL, %s, %s, %s)', (userName, email, password))
            connection.commit()  # Corrected commit call
            message = 'You have successfully registered!'
    
        connection.close()  # Close the connection when done
    return render_template('register.html', message=message)

#login page
@app.route('/login', methods=['GET', 'POST'])
def login():
    message = ''
    if request.method == 'POST' and 'email' in request.form and 'password' in request.form:
        email = request.form['email']
        password = request.form['password']
        connection = pymysql.connect(host='localhost', user='root', password='', database='chat')

        # Create cursor
        cursor = connection.cursor()  # Create a cursor from the connection
        cursor.execute('SELECT * FROM flask_users WHERE email = %s AND password = %s', (email, password))
        user = cursor.fetchone()
        if user:
            session['loggedin'] = True
            session['id'] = user[0] if user[0] else None  # Accessing by index
            session['username'] = user[1]  # Assuming username is the second column
            session['email'] = user[2]  # Assuming email is the third column
            message = 'Logged in successfully!'
            return render_template('user.html', message=message)
        else:
            message = 'Please enter correct email/password!'
    return render_template('login.html', message=message)


@app.route('/logout')
def logout():
    session.pop('loggedin', None)
    session.pop('id', None)
    session.pop('email', None)
    return redirect(url_for('login'))

@app.route('/index', methods=['GET','POST'])
def index():
   message = ''
   if request.method == 'POST' and 'name' in request.form and 'email' in request.form and 'subject' in request.form and 'message' in request.form:
        name = request.form['name']
        email = request.form['email']
        subject = request.form['subject']
        message_text = request.form['message']
        # Establish pymysql connection
        connection = pymysql.connect(host='localhost', user='root', password='', database='chat')
        try:
            # Create cursor 
            cursor = connection.cursor()
            # Execute INSERT query
            cursor.execute('INSERT INTO comments (name, email, subject, message) VALUES (%s, %s, %s, %s)', (name, email, subject, message_text))
            # Commit changes
            connection.commit()
            message = 'Your message has been submitted successfully!'
        except Exception as e:
            # Rollback changes on error
            connection.rollback()
            message = 'An error occurred while processing your request.'
        finally:
            # Close cursor and connection
            cursor.close()
            connection.close()
   return render_template('indexwebpg.html', message=message)

@app.route('/query')
def query():
    return render_template('query.html')

@app.route('/process', methods=['POST'])
def process():
    if request.method == 'POST':
        my_bytes_value = request.data.decode().replace("'", '"')
        input_value = json.loads(my_bytes_value)['input']
        result = final_.find_and_map_place_names(input_value, 'States')
        result += final_.find_and_map_place_names(input_value, 'Countries')
        result += final_.find_and_map_place_names(input_value, 'Cities')
        return jsonify({'result': result})

if __name__ == '__main__':
    app.run(debug=True)
